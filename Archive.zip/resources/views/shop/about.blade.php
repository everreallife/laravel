@extends('layouts.master')

@section('title')
  Laravel 5.4 Shopping Cart
@endsection


 <!--================Home Banner Area =================-->
  <!-- breadcrumb start-->
  <section class="breadcrumb breadcrumb_bg">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="breadcrumb_iner">
            <div class="breadcrumb_iner_item">
              <h2>About Us</h2>
              <p>Home <span>-</span> about us</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- breadcrumb start-->

  <!-- ================ contact section start ================= -->
  <section class="contact-section padding_top">
    <div class="container">
     

      <div class="row">
        <div class="col-12">
          <h2 class="contact-title">About Cowrisha</h2>
        </div>
        <div class="col-lg-8">
          <p>
          The cowrisha bracelet is a spiritual jewelry made with coweries in powerful West African orisha tradition. 
<br> <br>
This bracelet is a creation of cowry beads, seashells and glass in a 7 spirits of orisha tradition. The cowrisha has been around for centuries in different forms and shapes, bringing wealth and good fortune for ancient Africans.
<br> <br>
Here's why the cowrisha bracelet is so powerful to our ancestors: Ancient Africans wore the cowrisha for protection to ward off bad omen in order to attract wealth, good fortune and abundance. 
<br> <br>
Cowrisha is made in the form of white cowries in 7 spirits of orisha tradition which have many spiritual meanings and benefits. 
<br> <br>
Many woke Africans today wear this bracelet mainly for the purpose of good fortune, but the 7 spirits of Cowrisha is very instrumental in bringing many other good things into life.
<br> <br>
The 7 spirits or energies if you will, do the following in the life of the bearer
<br> <br>
1. Cleanses and purifies the body of the host from all negativities
<br> <br>
2. Regulate the energy of the body to transmit only positive vibrations
<br> <br>
3. Connects the body to the cosmos and grants it open doors to manifest its desires
<br> <br>
4. It attracts wealth and abundance according to your needs and capacity
<br> <br>
5. It protects and drives away evil from your life; and blocks riches and abundance from leaving your home.
<br> <br>
6. The Cowrisha releases a healing potent energy that transcends anxieties, healing all manner of diseases
<br> <br>
7. And finally give you peace of mind to live in freedom.
          </p>
        </div>
        <div class="col-lg-4">
          <!-- <div class="media contact-info">
            <span class="contact-info__icon"><i class="ti-home"></i></span>
            <div class="media-body">
              <h3>Buttonwood, California.</h3>
              <p>Rosemead, CA 91770</p>
            </div>
          </div>
          <div class="media contact-info">
            <span class="contact-info__icon"><i class="ti-tablet"></i></span>
            <div class="media-body">
              <h3>00 (440) 9865 562</h3>
              <p>Mon to Fri 9am to 6pm</p>
            </div>
          </div>
          <div class="media contact-info">
            <span class="contact-info__icon"><i class="ti-email"></i></span>
            <div class="media-body">
              <h3>support@colorlib.com</h3>
              <p>Send us your query anytime!</p>
            </div>
          </div> -->
        </div>
      </div>
    </div>
  </section>
  <!-- ================ contact section end ================= -->


