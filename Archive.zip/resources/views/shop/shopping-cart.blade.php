@extends('layouts.master')

@section('title')
    Product in the shopping cart
@endsection


@section('content')
    @if(Session::has('cart'))

      <!--================Cart Area =================-->
  <section class="cart_area padding_top">
    <div class="container">
      <div class="cart_inner">

    

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Product</th>
                <th scope="col">Quantity</th>
                <th scope="col">Price</th>
                
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>


            @foreach($products as $product)
              <tr>
                <td>
                  <div class="media">
                    <div class="d-flex">
                      <img style="width:100px;" src="img/product/p1.jpeg" alt="" />
                    </div>
                    <div class="media-body">
                      <p>{{ $product['item']  ['title'] }}</p>
                    </div>
                  </div>
                </td>
               
                <td>
                  <div class="product_count">
                   
                    <input class="input-number" readonly type="text" value="{{ $product['qty'] }}" >
                    
                  </div>
                </td>
                <td>
                  <h5>₦{{ $product['price'] }} </h5>
                </td>

                <td>
                <div class="btn-group">
                    <button class="btn btn-primary btn-xs dropdown-toggle" type="button" data-toggle="dropdown"> Action
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                    <li><a href="{{ route('product.deductByOne', ['product' => $product['item']['id']]) }}">Remove One</a> </li>
                    <li><a href="{{ route('product.removeItem', ['product' => $product['item']['id']]) }}">Delete all</a> </li>
                    </ul>
                </div>
                </td>

              </tr>
              @endforeach
              
            </tbody>
          </table>
          <div class="checkout_btn_inner float-right">
            <div class="row">
            
                <strong>Total price: ₦{{ $totalPrice }}</strong> - $100.00
           <br><br>
            </div>
            <!-- <a class="btn_1" href="#">Continue Shopping</a> -->
            <a class="btn_3 checkout_btn_1" href="{{ route('checkout') }}">Checkout</a>
          </div>
        </div>
      </div>
  </section>
  <!--================End Cart Area =================-->




       
    @else
    <section class="cart_area padding_top">
        <div class="container">

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <h2>The are no products in the shopping cart!</h2>
            </div>
        </div>
        </div>
    </section>
    @endif
@endsection