<!-- Spinner Start -->
<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->
    
<header class="main_menu home_menu">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="/"> <img style="width:150px;" src="{{ asset('img/logo.png') }}" alt="logo"> </a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="menu_icon"><i class="fas fa-bars"></i></span>
                        </button>

                        <div class="collapse navbar-collapse main-menu-item" id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a class="nav-link" href="/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="details">Buy</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about">About</a>
                                </li>
                                
                                
                                
                                <li class="nav-item">
                                    <a class="nav-link" href="contact">Contact</a>
                                </li>

                                @if(Auth::check())
             <li class="nav-item"><a class="nav-link" href="{{ route('user.profile') }}">User Profile</a></li>

             <li role="separator" class="nav-item"><a class="nav-link" href="#"></a></li>
             <li class="nav-item"><a class="nav-link" href="{{ route('user.logout') }}">Logout</a></li>
           @else
             <li class="nav-item"><a class="nav-link" href="{{ route('user.signup') }}">Signup</a></li>
             <li class="nav-item"><a class="nav-link" href="{{ route('user.signin') }}">Signin</a></li>
           @endif

                            </ul>
                        </div>
                        <div class="hearer_icon d-flex">
                            
                            <div class="dropdown">
                                <a class="" style="font-size:2em;" href="{{ route('product.shoppingcart') }}"  >
                                    <i class="fas fa-cart-plus"></i>
                                    <span class="badge" >{{ Session::has('cart') ? Session::get('cart')->totalQty : '' }}</span>
                                </a>
                               
                                
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        </header>

<!-- navigation -->
<!-- <nav class="navbar navbar-default">
 <div class="container-fluid">
   <div class="navbar-header">
     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
       <span class="icon-bar"></span>
     </button>
     <a class="navbar-brand" href="{{ route('product.index') }}">HenryLab Shopping Cart&trade;</a>
   </div>
   <div class="collapse navbar-collapse" id="myNavbar">
     <ul class="nav navbar-nav navbar-right">

       <li >
           <a href="{{ route('product.shoppingcart') }}">
               <i class="fa fa-shopping-cart" aria-hidden="true"></i> Shopping Cart
               <span class="badge">{{ Session::has('cart') ? Session::get('cart')->totalQty : '' }}</span>
           </a>
       </li>
       <li class="dropdown">
         <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" >
           <i class="fa fa-user" aria-hidden="true"></i>
           User Management
           <span class="caret"></span>
         </a>
         <ul class="dropdown-menu">
           @if(Auth::check())
             <li><a href="{{ route('user.profile') }}">User Profile</a></li>

             <li role="separator" class="divider"><a href="#"></a></li>
             <li><a href="{{ route('user.logout') }}">Logout</a></li>
           @else
             <li><a href="{{ route('user.signup') }}">Signup</a></li>
             <li><a href="{{ route('user.signin') }}">Signin</a></li>
           @endif
         </ul>
       </li>
     </ul>
   </div>
 </div>
</nav> -->

<!-- end navigation -->
