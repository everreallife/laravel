<?php $__env->startSection('title'); ?>
    Product in the shopping cart
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <?php if(Session::has('cart')): ?>

      <!--================Cart Area =================-->
  <section class="cart_area padding_top">
    <div class="container">
      <div class="cart_inner">

    

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">Product</th>
                <th scope="col">Quantity</th>
                <th scope="col">Price</th>
                
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>


            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <div class="media">
                    <div class="d-flex">
                      <img style="width:100px;" src="img/product/p1.jpeg" alt="" />
                    </div>
                    <div class="media-body">
                      <p><?php echo e($product['item']  ['title']); ?></p>
                    </div>
                  </div>
                </td>
               
                <td>
                  <div class="product_count">
                   
                    <input class="input-number" readonly type="text" value="<?php echo e($product['qty']); ?>" >
                    
                  </div>
                </td>
                <td>
                  <h5>₦<?php echo e($product['price']); ?> </h5>
                </td>

                <td>
                <div class="btn-group">
                    <button class="btn btn-primary btn-xs dropdown-toggle" type="button" data-toggle="dropdown"> Action
                    <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('product.deductByOne', ['product' => $product['item']['id']])); ?>">Remove One</a> </li>
                    <li><a href="<?php echo e(route('product.removeItem', ['product' => $product['item']['id']])); ?>">Delete all</a> </li>
                    </ul>
                </div>
                </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
          </table>
          <div class="checkout_btn_inner float-right">
            <div class="row">
            
                <strong>Total price: ₦<?php echo e($totalPrice); ?></strong> - $100.00
           <br><br>
            </div>
            <!-- <a class="btn_1" href="#">Continue Shopping</a> -->
            <a class="btn_3 checkout_btn_1" href="<?php echo e(route('checkout')); ?>">Checkout</a>
          </div>
        </div>
      </div>
  </section>
  <!--================End Cart Area =================-->




       
    <?php else: ?>
    <section class="cart_area padding_top">
        <div class="container">

        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <h2>The are no products in the shopping cart!</h2>
            </div>
        </div>
        </div>
    </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>