<?php $__env->startSection('title'); ?>
  Cowrisha Shop
<?php $__env->stopSection(); ?>


<!-- Spinner Start -->
<div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

<!-- banner part start-->
<section class="banner_part">
        <div class="container">

       
      <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="banner_slider owl-carousel">
                        <div class="single_banner_slider">
                            <div class="row">
                                <div class="col-lg-5 col-md-8">
                                    <div class="banner_text">
                                        <div class="banner_text_iner">
                                            <h1>SPIRITUAL BRACELET</h1>
                                            <p>The Cowrisha is a spiritual bracelet of West African descent made with cowries in powerful orisha tradition.</p>
                                            <?php $__currentLoopData = $products->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $productChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <a href="<?php echo e(route('product.addtocart', ['id' => $product->id])); ?>" class="btn_2">add to cart</a> <a href="details" class="btn_1">More Details</a>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="banner_img d-none d-lg-block">
                                    <img src="<?php echo e(asset('img/ban2.jpeg')); ?>" style="width:500px; margin-top:-20px;" alt="">
                                </div>
                            </div>
                        </div><div class="single_banner_slider">
                            <div class="row">
                                <div class="col-lg-5 col-md-8">
                                    <div class="banner_text">
                                        <div class="banner_text_iner">
                                            <h1>Beads, Seashells
                                                & Glass</h1>
                                            <p>The bracelet is a creation of cowry beads, seashells and glass in a 7 spirits of orisha tradition</p>
                                            <a href="<?php echo e(route('product.addtocart', ['id' => $product->id])); ?>" class="btn_2">add to cart</a> <a href="about" class="btn_1">More Details</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="banner_img d-none d-lg-block">
                                <img src="<?php echo e(asset('img/ban3.jpeg')); ?>" style="width:500px" alt="">
                                </div>
                            </div>
                        </div><div class="single_banner_slider">
                            <div class="row">
                                <div class="col-lg-5 col-md-8">
                                    <div class="banner_text">
                                        <div class="banner_text_iner">
                                            <h1>energy of the ocean goddess</h1>
                                            <p>The bearer of the cowrisha Jewelry carries the energy of the ocean goddess which brings good health, wealth and abundance.</p>
                                            <a href="<?php echo e(route('product.addtocart', ['id' => $product->id])); ?>" class="btn_2">add to cart</a> <a href="about" class="btn_1">More Details</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="banner_img d-none d-lg-block">
                                <img src="<?php echo e(asset('img/ban1.jpeg')); ?>" style="width:500px" alt="">
                                </div>
                            </div>
                        </div>
                     
                    </div>
                    <div class="slider-counter"></div>
                </div>
            </div>
      
 


            




        </div>
    </section>
    <!-- banner part start-->
    <!-- <div class="col-sm-4 col-md-4">
          <div class="thumbnail">
            <img src="<?php echo URL::to('images/uploads',array($product->imagePath)); ?>  " alt="Product" class="img-responsive">
            <div class="caption">
              <h3><?php echo e($product->title); ?></h3>
              <p class="description"><?php echo e($product->description); ?></p>
              <div class="clearfix">
                <div class="pull-left cost">
                  $ <?php echo e($product->price); ?>

                </div>
                <a href="<?php echo e(route('product.addtocart', ['id' => $product->id])); ?>" class="btn btn-success pull-right" role="button">Add to cart</a>
              </div>
            </div>
          </div>
        </div> -->
    <!-- feature_part start-->
    <!-- <section class="feature_part padding_top">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="section_tittle text-center">
                        <h2>Featured Category</h2>
                    </div>
                </div>
            </div>
            <div class="row align-items-center justify-content-between">
                <div class="col-lg-7 col-sm-6">
                    <div class="single_feature_post_text">
                        <p>Premium Quality</p>
                        <h3>Latest foam Sofa</h3>
                        <a href="#" class="feature_btn">EXPLORE NOW <i class="fas fa-play"></i></a>
                        <img src="<?php echo e(asset('img/feature/feature_1.png')); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-5 col-sm-6">
                    <div class="single_feature_post_text">
                        <p>Premium Quality</p>
                        <h3>Latest foam Sofa</h3>
                        <a href="#" class="feature_btn">EXPLORE NOW <i class="fas fa-play"></i></a>
                        <img src="<?php echo e(asset('img/feature/feature_2.png')); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-5 col-sm-6">
                    <div class="single_feature_post_text">
                        <p>Premium Quality</p>
                        <h3>Latest foam Sofa</h3>
                        <a href="#" class="feature_btn">EXPLORE NOW <i class="fas fa-play"></i></a>
                        <img src="<?php echo e(asset('img/feature/feature_3.png')); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-7 col-sm-6">
                    <div class="single_feature_post_text">
                        <p>Premium Quality</p>
                        <h3>Latest foam Sofa</h3>
                        <a href="#" class="feature_btn">EXPLORE NOW <i class="fas fa-play"></i></a>
                        <img src="<?php echo e(asset('img/feature/feature_4.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- upcoming_event part start -->

   
    <!-- subscribe_area part start-->
    <section class="subscribe_area section_padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="subscribe_area_text text-center">
                        <h5>Join Our Newsletter</h5>
                        <h2>Subscribe to get Updated
                            with new offers</h2>
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="enter email address"
                                aria-label="Recipient's username" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <a href="#" class="input-group-text btn_2" id="basic-addon2">subscribe now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--::subscribe_area part end::-->



<!-- START-->
<?php $__env->startSection('content'); ?>
  <?php if(Session::has('success')): ?>
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div id="charge-message" class="alert alert-success">
        <?php echo e(Session::get('success')); ?>

      </div>
    </div>
  </div>
  <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>